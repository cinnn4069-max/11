# Keymap (Android starter)

Kotlin starter for an "Edit keymap" feature. Uses the same JSON as the web editor
(`{"name":..., "buttons":[{id,t,x,y,s,l,k,c}]}`), so you can design on the web, copy the export,
and use "Import mapping from clipboard" in the app.

## Set up
1. Android Studio -> New Project -> "Empty Views Activity", package `com.example.keymap`, min SDK 30, Kotlin.
2. Replace `AndroidManifest.xml` and copy the `.kt` files and `res/` files from this folder.
3. Run it, then in the app:
   - Allow display over other apps
   - Turn on "Keymap" under Accessibility (on Android 13+ sideloaded builds, first open
     App info -> menu -> "Allow restricted settings")
   - Tap "Edit keymap", switch to your game, drag buttons, tap one to rename or bind a key, press Done.

## What works / what is missing
- Works: overlay editor (drag, add, rename, rebind, delete), saved in SharedPreferences,
  physical key -> tap via AccessibilityService.dispatchGesture.
- Missing: joystick (needs a held/continued gesture: GestureDescription.willContinue + continueStroke),
  look area, per-app profiles, opacity/color settings screen, and faster injection (Shizuku/ADB).
- Not compiled or tested yet.

## Build the APK without Android Studio (GitHub)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder (keep the `.github` folder) to the repository.
3. Open the Actions tab -> "Build APK" -> wait for the green check (a few minutes).
   If it didn't start, choose "Run workflow".
4. Open the finished run, download the `keymap-apk` artifact, unzip it, and install `app-debug.apk` on your phone
   (allow "Install unknown apps" for your browser or file manager).
