package com.example.keymap

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.view.ContextThemeWrapper
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlin.math.abs

/** Draws the keymap on top of the game. Drag a button to move it, tap it to rename / rebind / delete. */
class EditorOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var buttons: MutableList<KeyButton>

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("keymap", "Keymap editor", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "keymap")
            .setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle("Editing keymap").build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        if (root == null) show()
        return START_NOT_STICKY
    }

    private fun show() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buttons = KeymapStore.load(this)
        val r = FrameLayout(this).apply { setBackgroundColor(0x88000000.toInt()) }
        root = r
        render()
        wm.addView(r, WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT))
    }

    private fun render() {
        val r = root ?: return
        r.removeAllViews()
        buttons.forEach { addButtonView(r, it) }
        val bar = LinearLayout(this).apply {
            addView(Button(context).apply {
                text = "+ Add"
                setOnClickListener {
                    buttons += KeyButton(buttons.maxOfOrNull { it.id }?.plus(1) ?: 1, "tap", 50f, 50f, 9f, "Tap", mutableListOf(""))
                    render()
                }
            })
            addView(Button(context).apply {
                text = "Done"
                setOnClickListener { KeymapStore.save(this@EditorOverlayService, buttons); stopSelf() }
            })
        }
        r.addView(bar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(24, 64, 24, 0) })
    }

    private fun addButtonView(parent: FrameLayout, b: KeyButton) {
        val (sw, sh) = screenSize(this)
        val d = (b.size / 100f * sw).toInt()
        val c = b.colorInt()
        val tv = TextView(this).apply {
            text = if (b.type == "joy") "${b.label}\nWASD" else "${b.label}\n${b.keys.firstOrNull().orEmpty()}"
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f
            background = GradientDrawable().apply {
                shape = if (b.type == "look") GradientDrawable.RECTANGLE else GradientDrawable.OVAL
                cornerRadius = d * 0.14f
                setColor((c and 0x00FFFFFF) or 0x55000000); setStroke(4, c)
            }
        }
        val lp = FrameLayout.LayoutParams(d, d).apply {
            leftMargin = (b.x / 100f * sw - d / 2f).toInt(); topMargin = (b.y / 100f * sh - d / 2f).toInt()
        }
        var offX = 0f; var offY = 0f; var downX = 0f; var downY = 0f; var moved = false
        tv.setOnTouchListener { v, e ->
            val p = v.layoutParams as FrameLayout.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { offX = e.rawX - p.leftMargin; offY = e.rawY - p.topMargin; downX = e.rawX; downY = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - downX) + abs(e.rawY - downY) > 12) moved = true
                    p.leftMargin = (e.rawX - offX).toInt(); p.topMargin = (e.rawY - offY).toInt(); v.layoutParams = p
                }
                MotionEvent.ACTION_UP -> {
                    b.x = ((p.leftMargin + d / 2f) / sw * 100f).coerceIn(0f, 100f)
                    b.y = ((p.topMargin + d / 2f) / sh * 100f).coerceIn(0f, 100f)
                    if (!moved) editDialog(b)
                }
            }
            true
        }
        parent.addView(tv, lp)
    }

    private fun editDialog(b: KeyButton) {
        val ctx = ContextThemeWrapper(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
        val label = EditText(ctx).apply { hint = "Name"; setText(b.label) }
        val key = EditText(ctx).apply { hint = "Key (for example E or Space)"; setText(b.keys.firstOrNull().orEmpty()) }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 16, 48, 0)
            addView(label); if (b.type == "tap") addView(key)
        }
        AlertDialog.Builder(ctx).setView(box)
            .setPositiveButton("Save") { _, _ ->
                b.label = label.text.toString()
                if (b.type == "tap") { if (b.keys.isEmpty()) b.keys.add(""); b.keys[0] = key.text.toString().trim() }
                render()
            }
            .setNegativeButton("Delete") { _, _ -> buttons.remove(b); render() }
            .setNeutralButton("Cancel", null)
            .create().apply { window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY); show() }
    }

    override fun onDestroy() { root?.let { wm.removeView(it) }; root = null; super.onDestroy() }
}
