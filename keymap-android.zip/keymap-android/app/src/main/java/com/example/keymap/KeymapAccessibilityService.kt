package com.example.keymap

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

/** Listens for physical keyboard keys and turns a matching "tap" button into a screen tap. */
class KeymapAccessibilityService : AccessibilityService() {

    override fun onKeyEvent(e: KeyEvent): Boolean {
        val name = KeyEvent.keyCodeToString(e.keyCode).removePrefix("KEYCODE_")
        val b = KeymapStore.load(this).firstOrNull { btn ->
            btn.type == "tap" && btn.keys.any { it.equals(name, ignoreCase = true) }
        } ?: return false                       // not mapped: let the key through
        if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) tap(b)
        return true                             // swallow both DOWN and UP of mapped keys
    }

    private fun tap(b: KeyButton) {
        val (w, h) = screenSize(this)
        val path = Path().apply { moveTo(b.x / 100f * w, b.y / 100f * h) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build()
        dispatchGesture(gesture, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
