package com.example.keymap

import android.app.Activity
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, f: () -> Unit) = box.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        btn("1. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Turn on the Keymap accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("Edit keymap") {
            startForegroundService(Intent(this, EditorOverlayService::class.java))
            moveTaskToBack(true)
        }
        btn("Import mapping from clipboard") {
            val text = getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
            try {
                KeymapStore.save(this, KeymapStore.fromJson(text))
                Toast.makeText(this, "Mapping imported", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this, "This isn’t a valid mapping", Toast.LENGTH_SHORT).show()
            }
        }
        setContentView(box)
    }
}
