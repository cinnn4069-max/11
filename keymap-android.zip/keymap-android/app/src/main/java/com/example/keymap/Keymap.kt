package com.example.keymap

import android.content.Context
import android.graphics.Color
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** One on-screen button. x/y are the CENTER as a percent (0..100) of the screen. size is percent of screen width. */
data class KeyButton(
    var id: Int,
    var type: String,            // "tap" | "joy" | "look"  (same names as the web editor)
    var x: Float,
    var y: Float,
    var size: Float,
    var label: String,
    var keys: MutableList<String>,
    var color: String = ""
) {
    fun colorInt(): Int = runCatching { Color.parseColor(color) }.getOrDefault(0xFF4A63F0.toInt())
}

object KeymapStore {
    private const val PREFS = "keymap"

    fun load(ctx: Context): MutableList<KeyButton> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("buttons", null)
            ?: return mutableListOf()
        return runCatching { fromJson(raw) }.getOrDefault(mutableListOf())
    }

    fun save(ctx: Context, list: List<KeyButton>) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("buttons", toJson(list)).apply()
    }

    fun toJson(list: List<KeyButton>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("t", it.type).put("x", it.x.toDouble())
                .put("y", it.y.toDouble()).put("s", it.size.toDouble()).put("l", it.label)
                .put("k", JSONArray(it.keys)).put("c", it.color))
        }
        return JSONObject().put("name", "My game").put("buttons", arr).toString()
    }

    /** Accepts the web editor's export: {"name":..., "buttons":[...]} (or a bare array). */
    fun fromJson(raw: String): MutableList<KeyButton> {
        val root = JSONTokener(raw).nextValue()
        val arr = if (root is JSONObject) root.getJSONArray("buttons") else root as JSONArray
        val out = mutableListOf<KeyButton>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val t = o.getString("t")
            require(t in listOf("tap", "joy", "look"))
            val k = o.optJSONArray("k")
            out += KeyButton(
                id = i + 1, type = t, x = o.getDouble("x").toFloat(), y = o.getDouble("y").toFloat(),
                size = o.optDouble("s", 10.0).toFloat(), label = o.optString("l"),
                keys = MutableList(k?.length() ?: 0) { n -> k!!.getString(n) }, color = o.optString("c")
            )
        }
        return out
    }
}

fun screenSize(ctx: Context): Pair<Int, Int> {
    val b = ctx.getSystemService(WindowManager::class.java).maximumWindowMetrics.bounds
    return b.width() to b.height()
}
